﻿using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Http;

namespace Backend.Application.DTOs;

public class UpdateBookDto
{
    [Required]
    [StringLength(255)]
    public string Title { get; set; } = string.Empty;

    [Range(1, int.MaxValue)]
    public int? EditionNumber { get; set; }

    [StringLength(20)]
    public string? ISBN { get; set; }

    [Range(1000, 2100)]
    public int? PublicationYear { get; set; }

    public uint? PublisherId { get; set; }

    [Range(1, int.MaxValue)]
    public int? PageCount { get; set; }

    public string? Description { get; set; }

    public int? UserId { get; set; }
    // Ruta de la imagen de portada
    public IFormFile? CoverImage { get; set; }
    public List<int> AuthorIds { get; set; } = new();
    public List<int> CategoryIds { get; set; } = new();
  
}