﻿using Backend.Application.DTOs;
using Backend.Application.Interfaces;
using Backend.Domain.Validators;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Backend.Controllers;

[ApiController]
[Route("api/[controller]")]
public class BookController : ControllerBase
{
    private readonly IBookService _bookService;

    public BookController(IBookService bookService)
    {
        _bookService = bookService;
    }

    // ============================================================
    // GET ALL
    // ============================================================

    [HttpGet]
    public async Task<ActionResult<IEnumerable<BookDto>>> GetAll()
    {
        var books = await _bookService.GetAllAsync();

        return Ok(books);
    }

    // ============================================================
    // GET BY ID
    // ============================================================

    [HttpGet("{id}")]
    public async Task<ActionResult<BookDto>> GetById(int id)
    {
        var book = await _bookService.GetByIdAsync((uint)id);

        if (book == null)
            return NotFound();

        return Ok(book);
    }

    // ============================================================
    // CREATE
    // ============================================================

    [HttpPost]
    public async Task<ActionResult<BookDto>> Create(
        [FromForm] CreateBookDto dto)
    {
        try
        {
            var book =
                await _bookService.CreateAsync(dto);

            return CreatedAtAction(
                nameof(GetById),
                new { id = book.Id },
                book);
        }
        catch (BookValidationException ex)
        {
            foreach (var error in ex.Errors)
            {
                foreach (var message in error.Value)
                {
                    ModelState.AddModelError(
                 
                        error.Key,
                        message);
                }
            }

            return ValidationProblem(ModelState);
        }
        catch (ArgumentException ex)
        {
            ModelState.AddModelError(
                string.Empty,
                ex.Message);

            return ValidationProblem(ModelState);
        }
        catch (InvalidOperationException ex)
        {
            return Conflict(new
            {
                message = ex.Message
            });
        }
    }

    // ============================================================
    // UPDATE
    // ============================================================

    [HttpPut("{id}")]
    public async Task<ActionResult<BookDto>> Update(
        int id,
        [FromForm] UpdateBookDto dto)
    {
        try
        {
            var book =
                await _bookService.UpdateAsync((uint)id, dto);

            if (book == null)
                return NotFound();

            return Ok(book);
        }
        catch (BookValidationException ex)
        {
            foreach (var error in ex.Errors)
            {
                foreach (var message in error.Value)
                {
                    ModelState.AddModelError(
                        error.Key,
                        message);
                }
            }

            return ValidationProblem(ModelState);
        }
        catch (ArgumentException ex)
        {
            ModelState.AddModelError(
                string.Empty,
                ex.Message);

            return ValidationProblem(ModelState);
        }
        catch (InvalidOperationException ex)
        {
            return Conflict(new
            {
                message = ex.Message
            });
        }
    }

    // ============================================================
    // DELETE
    // ============================================================

    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(int id)
    {
        var deleted =
            await _bookService.DeleteAsync((uint)id);

        if (!deleted)
            return NotFound();

        return NoContent();
    }

    // ============================================================
    // SEARCH
    // ============================================================

    [HttpGet("search")]
    public async Task<ActionResult<IEnumerable<BookDto>>> Search(
        [FromQuery] string? phrase = null)
    {
        var books =
            await _bookService.SearchAsync(phrase);

        return Ok(books);
    }

    [HttpGet("available")]
    public async Task<ActionResult<IEnumerable<BookDto>>> GetAvailable()
    {
        var books = await _bookService.GetAvailableAsync();
        return Ok(books);
    }

    public record AddCopyRequest(string InternalCode);

    [HttpPost("{id}/copies")]
    public async Task<IActionResult> AddCopy(int id, [FromBody] AddCopyRequest request)
    {
        var error = await _bookService.AddCopyAsync((uint)id, request.InternalCode);

        if (error != null)
            return BadRequest(new { message = error });

        return Ok(new { message = "Copia agregada correctamente." });
    }
}